// ============================================================
// PERSONALIZE HERE
// Change these two names. You can also edit the messages in index.html.
// ============================================================
const girlfriendName = "BABY";
const yourName = "YOUR NAME";

// 20 Things data — edit any title/message you want.
const things = [
  ["Your smile", "It can genuinely make my whole mood better."],
  ["The way you laugh", "Especially when you laugh at something completely random."],
  ["Your personality", "There is just something about you that feels so uniquely you."],
  ["How you care about people", "You care more than you probably realize."],
  ["Your little habits", "Even the tiny things you do have become things I adore."],
  ["The way you talk to me", "I love our random conversations and the little things you tell me."],
  ["Your kindness", "Your heart has so much softness in it."],
  ["Your patience", "Thank you for understanding me even when I am a little difficult."],
  ["Your cute reactions", "I could probably watch your reactions forever."],
  ["Your beautiful heart", "This is one of the biggest reasons I love you."],
  ["Your sense of humor", "You somehow manage to make ordinary moments funny."],
  ["The way you make me feel loved", "You make me feel like I matter, and that means everything."],
  ["Your determination", "I love seeing you keep going after what you want."],
  ["Your little random moments", "The unexpected moments with you are some of my favorites."],
  ["Your beautiful eyes", "Yeah... I definitely get distracted sometimes. ♡"],
  ["How comfortable I feel around you", "With you, I can just be myself."],
  ["The memories we make", "Every memory with you becomes something I want to keep."],
  ["The way you make my bad days better", "Sometimes just talking to you is enough."],
  ["Simply because you're you", "I don't need a complicated reason. I love you for you."],
  ["Everything about you ❤️", "Twenty reasons barely scratches the surface. I love all of you."]
];

const pages = [...document.querySelectorAll(".page")];
const navLinks = [...document.querySelectorAll(".nav-link")];
const progressText = document.getElementById("progressText");
const progressFill = document.getElementById("progressFill");
const particleLayer = document.getElementById("particle-layer");
const audio = document.getElementById("birthdayAudio");
const musicToggle = document.getElementById("musicToggle");
const musicIcon = document.getElementById("musicIcon");

let currentPage = 0;
let previousPage = 0;
let letterStarted = false;
let confettiShown = false;

function showPage(index, direction = 1) {
  index = Math.max(0, Math.min(pages.length - 1, index));
  previousPage = currentPage;
  currentPage = index;

  pages.forEach((page, i) => {
    page.classList.toggle("active", i === index);
  });

  navLinks.forEach((link, i) => {
    link.classList.toggle("active", i === index);
  });

  progressText.textContent = `${String(index + 1).padStart(2, "0")} / 05`;
  progressFill.style.width = `${((index + 1) / 5) * 100}%`;

  // Keep the active page at the top.
  pages[index].scrollTo({ top: 0, behavior: "instant" });

  if (index === 1 && !letterStarted) {
    startLetter();
  }

  if (index === 4 && !confettiShown) {
    confettiShown = true;
    launchConfetti();
  }
}

function startLetter() {
  letterStarted = true;

  // Change the letter here if you want a different message.
  const message = `My love,

Happy 20th birthday. I honestly don't know if words will ever be enough to explain how much you mean to me, but I still want to try.

I'm really grateful that I get to be part of your life and that I get to celebrate another year of you. You deserve so much happiness, love, peace, and all the little things that make your heart happy.

I hope this new chapter of your life brings you closer to the things you've always dreamed about. I hope you continue growing into the person you want to become, while never forgetting how amazing you already are.

Thank you for being you. Thank you for the memories, the conversations, the laughs, the random moments, and even the little things that probably don't seem important but mean so much to me.

I love you, and I'm so happy that I get to call you mine.

Happy 20th birthday, baby. ❤️`;

  document.getElementById("letterSignature").textContent = `Forever yours, ♡ ${yourName}`;

  const target = document.getElementById("letterText");
  target.textContent = "";

  let i = 0;
  const speed = 13;

  function type() {
    if (i < message.length) {
      target.textContent += message.charAt(i++);
      setTimeout(type, speed);
    }
  }

  type();
}

// Navigation
navLinks.forEach(link => {
  link.addEventListener("click", () => showPage(Number(link.dataset.page)));
});

document.querySelector(".brand").addEventListener("click", () => showPage(0));

document.querySelectorAll(".next-btn").forEach(btn => {
  btn.addEventListener("click", () => showPage(Number(btn.dataset.next)));
});

document.getElementById("replayBtn").addEventListener("click", () => {
  confettiShown = false;
  showPage(0);
});

// Keyboard navigation
document.addEventListener("keydown", e => {
  if (e.key === "ArrowRight") showPage(currentPage + 1);
  if (e.key === "ArrowLeft") showPage(currentPage - 1);
  if (e.key === "Escape") closeLightbox();
});

// 20 Things cards
const thingsGrid = document.getElementById("thingsGrid");

things.forEach(([title, message], index) => {
  const card = document.createElement("article");
  card.className = "thing-card";
  card.tabIndex = 0;
  card.innerHTML = `
    <div class="thing-face thing-front">
      <span class="thing-number">${String(index + 1).padStart(2, "0")}</span>
      <div class="thing-title">${title}</div>
      <span class="thing-number">tap me ♡</span>
    </div>
    <div class="thing-face thing-back">
      <span class="thing-number">${String(index + 1).padStart(2, "0")}</span>
      <p>${message}</p>
      <span>♡</span>
    </div>
  `;

  const flip = () => {
    card.classList.toggle("flipped");
    if (card.classList.contains("flipped")) {
      heartBurst(card);
    }
  };

  card.addEventListener("click", flip);
  card.addEventListener("keydown", e => {
    if (e.key === "Enter" || e.key === " ") {
      e.preventDefault();
      flip();
    }
  });

  thingsGrid.appendChild(card);
});

// Photo lightbox
const lightbox = document.getElementById("lightbox");
const lightboxImage = document.getElementById("lightboxImage");
const lightboxCaption = document.getElementById("lightboxCaption");

document.querySelectorAll(".polaroid").forEach(card => {
  card.addEventListener("click", () => {
    const img = card.querySelector("img");
    const caption = card.querySelector("figcaption").textContent;
    lightboxImage.src = img.src;
    lightboxImage.alt = img.alt;
    lightboxCaption.textContent = caption;
    lightbox.classList.add("open");
    lightbox.setAttribute("aria-hidden", "false");
  });
});

function closeLightbox() {
  lightbox.classList.remove("open");
  lightbox.setAttribute("aria-hidden", "true");
}

document.getElementById("lightboxClose").addEventListener("click", closeLightbox);
lightbox.addEventListener("click", e => {
  if (e.target === lightbox) closeLightbox();
});

// Music toggle — no autoplay.
musicToggle.addEventListener("click", async () => {
  try {
    if (audio.paused) {
      await audio.play();
      musicIcon.textContent = "Ⅱ";
      musicToggle.classList.add("playing");
    } else {
      audio.pause();
      musicIcon.textContent = "♫";
      musicToggle.classList.remove("playing");
    }
  } catch {
    alert("Add your music file at audio/birthday-song.mp3 first! ♡");
  }
});

audio.addEventListener("ended", () => {
  musicIcon.textContent = "♫";
  musicToggle.classList.remove("playing");
});

// Floating hearts + sparkles
const symbols = ["♡", "♥", "✦", "✧", "⋆"];

function spawnParticle() {
  const particle = document.createElement("span");
  particle.className = Math.random() > .35 ? "particle" : "sparkle";
  particle.textContent = symbols[Math.floor(Math.random() * symbols.length)];
  particle.style.left = `${Math.random() * 100}%`;
  particle.style.fontSize = `${10 + Math.random() * 17}px`;
  particle.style.animationDuration = `${5 + Math.random() * 7}s`;
  particle.style.animationDelay = `${Math.random() * 1.5}s`;
  particle.style.opacity = `${.25 + Math.random() * .55}`;
  particleLayer.appendChild(particle);
  setTimeout(() => particle.remove(), 13000);
}

setInterval(spawnParticle, 520);

// Small heart burst around clicked cards
function heartBurst(element) {
  const rect = element.getBoundingClientRect();

  for (let i = 0; i < 5; i++) {
    const heart = document.createElement("span");
    heart.className = "cursor-particle";
    heart.textContent = i % 2 ? "♡" : "♥";
    heart.style.left = `${rect.left + rect.width / 2 + (Math.random() * 50 - 25)}px`;
    heart.style.top = `${rect.top + rect.height / 2}px`;
    document.body.appendChild(heart);
    setTimeout(() => heart.remove(), 800);
  }
}

// Desktop cursor hearts
let lastCursor = 0;
document.addEventListener("mousemove", e => {
  const now = Date.now();
  if (now - lastCursor < 80) return;
  lastCursor = now;

  const heart = document.createElement("span");
  heart.className = "cursor-particle";
  heart.textContent = Math.random() > .5 ? "♡" : "✦";
  heart.style.left = `${e.clientX}px`;
  heart.style.top = `${e.clientY}px`;
  document.body.appendChild(heart);

  setTimeout(() => heart.remove(), 750);
});

// Confetti on final page
function launchConfetti() {
  const pieces = ["♡", "♥", "✦", "✧", "20", "✨"];

  for (let i = 0; i < 70; i++) {
    const piece = document.createElement("span");
    piece.className = "cursor-particle";
    piece.textContent = pieces[Math.floor(Math.random() * pieces.length)];
    piece.style.left = `${Math.random() * 100}vw`;
    piece.style.top = `${-10 - Math.random() * 20}px`;
    piece.style.fontSize = `${10 + Math.random() * 18}px`;
    piece.style.color = Math.random() > .5 ? "#f47eac" : "#fff";
    piece.style.animationDuration = `${1.7 + Math.random() * 2.5}s`;
    document.body.appendChild(piece);

    setTimeout(() => piece.remove(), 4500);
  }
}

// Touch swipe between pages
let touchStartX = 0;
document.addEventListener("touchstart", e => {
  touchStartX = e.changedTouches[0].clientX;
}, { passive: true });

document.addEventListener("touchend", e => {
  const delta = e.changedTouches[0].clientX - touchStartX;
  if (Math.abs(delta) < 70) return;
  if (delta < 0) showPage(currentPage + 1);
  else showPage(currentPage - 1);
}, { passive: true });

// Initial state
showPage(0);
